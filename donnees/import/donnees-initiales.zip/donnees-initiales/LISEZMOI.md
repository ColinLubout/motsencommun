# Données initiales de Mots en commun

Ces fichiers sont les données de départ du site : 73 entrées, 85 pièges et 82 exemples.

- `data/items/*.yaml` : une entrée par fichier, avec ses pièges.
- `data/sentences/0001-ai-placeholders.yaml` : les exemples. Ce sont des **phrases provisoires rédigées par une IA**, à remplacer ou à faire relire.
- `schema/` : le format et les vocabulaires de ces fichiers.

Tout a été rédigé par une IA et peut contenir des erreurs. La commande
`python manage.py importer_donnees_initiales <chemin>` les charge une seule fois,
avec le statut `brouillon` : rien n'est public avant d'avoir été relu.

Licence : CC BY 4.0, comme toutes les données de Mots en commun.
